<div class="about">
    <h1>about</h1>		
    <div>
        <p>Sistem Informasi Rumah Kost Berbasis Web. Diajukan untuk mengikuti ujian akhir tahun.</p>
		<p>Powered By TaufikAlfikriAhmad @2019 </p>
    </div>
</div>
