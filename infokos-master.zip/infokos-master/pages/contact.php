<div class="contact">
    <h1>contact us</h1>	
    <p>This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forum">Forum</a>.</p>		
    <div>
        <div>
            <h4>contact details</h4>
            <ul>
                <li>Location : 32 Morbi Suscipit Semquis Aliquet</li>
                <li>Consequat Sed placerat dui eget justo placerat, 1234</li>
                <li>Orders & Reservation Number : (061) 232-3706</li>
                <li>Office Phone Number : (061) 232-3553</li>
                <li>Fax Number : (061) 232-4160</li>
                <li>Email : infomasterkos@gmail.com</li>
            </ul>
        </div>		
        <div>
            <h4>store hours</h4>
            <ul>
                <li><span>Monday</span>9:00 am - 5:30</li>
                <li><span>Tuesday</span>9:00 am - 5:30</li>
                <li><span>Wednesday</span>9:00 am - 5:30</li>
                <li><span>Thursday</span>9:00 am - 5:30</li>
                <li><span>Friday</span>9:00 am - 5:30</li>
                <li><span>Saturday</span>9:00 am - 5:30</li>				
            </ul>
        </div>	
    </div>
</div>
